n = int(input())
list1 = []
for x in input().split():
    list1.append(int(x))
t = tuple(list1)
print(hash(t))
